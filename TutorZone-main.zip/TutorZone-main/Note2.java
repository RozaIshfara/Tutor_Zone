package com.example.myapplication;

import com.google.firebase.Timestamp;

public class Note2 {



    String title2;
    String subject2;
    String location2;
    String fee2;
    String contact2;
    String others2;
    Timestamp timestamp2;


    public Note2() {
    }

    public String getTitle2() {
        return title2;
    }

    public void setTitle2(String title2) {
        this.title2 = title2;
    }

    public String getSubject2() {
        return subject2;
    }

    public void setSubject2(String subject2) {
        this.subject2 = subject2;
    }

    public String getLocation2() {
        return location2;
    }

    public void setLocation2(String location2) {
        this.location2 = location2;
    }

    public String getFee2() {
        return fee2;
    }

    public void setFee2(String fee2) {
        this.fee2 = fee2;
    }

    public String getContact2() {
        return contact2;
    }

    public void setContact2(String contact2) {
        this.contact2 = contact2;
    }

    public String getOthers2() {
        return others2;
    }

    public void setOthers2(String others2) {
        this.others2 = others2;

    }

    public Timestamp getTimestamp2() {
        return timestamp2;
    }

    public void setTimestamp2(Timestamp timestamp2) {
        this.timestamp2 = timestamp2;
    }
}
